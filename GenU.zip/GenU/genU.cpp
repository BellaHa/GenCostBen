#include <iostream>
#include<fstream>
#include "option.h"
#include <ctime>
#include <cmath>
#include "sfmt/SFMT.h"

#if defined(_OPENMP)
#include <omp.h>
#else
typedef int omp_int_t;
inline omp_int_t omp_set_num_threads(int p) { return 1;}
inline omp_int_t omp_get_thread_num() { return 0;}
#endif


using namespace std;

int main(int argc, char ** argv)
{

    OptionParser op(argc, argv);
	if (!op.validCheck()){
		printf("Parameters error, please check the readme.txt file for correct format!\n");
		return -1;
	}

	char * inFile = op.getPara("-i");
	if (inFile == NULL){
		inFile = (char*)"network.bin";
	}
    char * outCostFile = op.getPara("-c");
	if (outCostFile == NULL){
		outCostFile = (char*)"nodes.cost";
	}
	char * outBenFile = op.getPara("-b");
	if (outBenFile == NULL){
		outBenFile = (char*)"nodes.ben";
	}
	char * temp = op.getPara("-p");
    int t = 4;
    if (temp != NULL){
		t = atoi(temp);
	}
  //  long long int numU;
    long long int numNodes;
  //  long long int numEdges;

    FILE * pFile;
    pFile = fopen(inFile, "rb");
    fread(&numNodes, sizeof(int), 1, pFile);
    	//fread(&numEdges, sizeof(long long), 1, pFile);
    //	numU = (long long int) 0.1*numNodes;*/
    //	numU = 200;
    cout<<"nodes:"<<numNodes<<endl;


    ofstream out1(outCostFile);

    omp_set_num_threads(t);
    sfmt_t sfmtSeed1;

    #pragma omp parallel
	for (unsigned int i = 1; i <=numNodes; ++i){
		//cout << 1 << " ";
		double tmp = sfmt_genrand_uint32(&sfmtSeed1)%10+1;
		//cout<<tmp<<endl;
		out1 << tmp<< endl;

	}
	out1.close();
	/*ofstream out2(outBenFile);
	for (unsigned int i = 1; i <=numNodes; ++i){
		//cout << 1 << " ";
		out2 << 1<< endl;
	}
	out2.close();
    */
    return 0;
}
